
# Updating Highlight.js

This build of highlight.js contains all languages. to achieve this, go to : https://highlightjs.org/download/

And run the following snipped in the console:

```
$$("input[type=checkbox]").forEach(function(checkbox) { checkbox.checked=true; })
```

This will tick all boxes instead of doing it by hand.
