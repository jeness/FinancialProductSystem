/**
 * <p>This set of service classes is designed to test the
 * {@link com.googlecode.jsonrpc4j.spring.AutoJsonRpcServiceImplExporter} bean used to
 * help with exposing JSON-RPC services.
 * </p>
 */

package com.googlecode.jsonrpc4j.spring.serviceb;
