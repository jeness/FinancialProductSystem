package com.googlecode.jsonrpc4j.util;

@SuppressWarnings({"serial", "WeakerAccess"})
public class TestThrowable extends Throwable {
	public TestThrowable(String message) {
		super(message);
	}
}
